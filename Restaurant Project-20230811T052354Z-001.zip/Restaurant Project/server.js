const server = require("./api");
server.listen(3000,function(){
    console.log("server is listening at port number 3000");
})
